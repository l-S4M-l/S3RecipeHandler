﻿class S3RGB:
    def __init__(self, R=0, G=0, B=0):
        self.r = R
        self.g = G
        self.b = B

